import turtle, random
from turtle import Shape
from tkinter import messagebox

turtle.setup(600,600)
#fenetre principale de l'application
fenetre = turtle.Screen()
fenetre.title("Toure de blocs")
fenetre.bgcolor("lightblue")
fenetre.tracer(0) # Turns off the screen updates
blocbase = turtle.Turtle()
bloc = turtle.Turtle()
bloc.speed(0)
bloc.penup()
bloc.goto(0,-450)
bloc.shape("square")
bloc.shapesize(2,7)
bloc.color("white")

#parametres initiaux a definir
maxblocs = 10
bloclargeur = 200
blochauteur = 40
blocbasecouleur = "grey"
blocbasecouleurligne = "black"
terrehauteur = 100 
terrelargeur = 600 # largeur de la fenetre
nbblocsajoutes = 0
nbblocsmalalignes = 0
nbblocspassurbase = 0
margeducentre = 35

# texte d'intro
def intro():
  messagebox.showinfo("Instructions","n - pour nouveau bloc \n a - bouger le bloc a gauche \n d - bouger le bloc a droite \n v - pour valider \n x - pour finir la simulation")

# a definir
def dessin_rectangle_colorie(blocbase,x,y,largeur,hauteur,tailleligne,couleur,remplissage):
  blocbase.fillcolor(remplissage)
  blocbase.pencolor(couleur)
  blocbase.pensize(tailleligne)
  blocbase.setheading(0)
  blocbase.speed(0)
 
  blocbase.begin_fill()
  blocbase.up()
  blocbase.goto(x,y)
  blocbase.down()
  # dessin haut
  blocbase.forward(largeur)
  # dessin droite
  blocbase.right(90)
  blocbase.forward(hauteur)
  # dessin bas
  blocbase.right(90)
  blocbase.forward(largeur)
  # dessin gauche
  blocbase.right(90)
  blocbase.forward(hauteur)
  blocbase.end_fill()
  blocbase.direction = "stop"
  blocbase.up()

def clone_bloc(nom,x,y,couleur):
  bloc_n = bloc.clone()
  if abs(round(bloc.xcor(), 0)) >= margeducentre: # mal centre mais sur la base
    bloc.color("black", "salmon")
    print("hors de la marge du centre")
    if abs(round(bloc.xcor(), 0)) >= ((bloclargeur/2)+70): # pas sur la base
        bloc.color("black", "red")
  else:
     bloc_n.color("black", "silver") # dans + ou - la marge du centre
  bloc.goto(x,y)
  bloc.color("black", couleur)
  valider()

def droite() :
  print("commande: droite")
  if bloc.xcor() < 220:
    bloc.forward(10)
    print(bloc.pos())
    valider()
  else:
    print("position a " + str(bloc.xcor()) + " - limite de la fenetre")
    messagebox.showwarning("Limite de la fenetre","Vous avez atteint la limite de la fenetre")
  
def gauche():
  print("commande: gauche")
  if bloc.xcor() > -220:
    bloc.forward(-10)
    print(bloc.pos())
    valider()
  else:
    print("position a " + str(bloc.xcor()) + " - limite de la fenetre")
    messagebox.showwarning("Limite de la fenetre","Vous avez atteint la limite de la fenetre")
    
  
# a definier
def nouveau_bloc():
  global nbblocsajoutes
  global nbblocsmalalignes
  global nbblocspassurbase
  n_bloc_nom = "bloc"+str(nbblocsajoutes+1)
  n_bloc_x = round(random.randint(-225,225),-1)
  #n_bloc_x = -bloclargeur/2 #pour les empiler au centre
  n_bloc_y = ((nbblocsajoutes+1)*blochauteur)-300+(terrehauteur+blochauteur-(blochauteur/2))
  if abs(round(bloc.xcor(), 5)) >= margeducentre:
    nbblocsmalalignes = nbblocsmalalignes+1
    print("1 bloc rouge de plus")
    if abs(round(bloc.xcor(), 5)) >= ((bloclargeur/2)+70):
      nbblocspassurbase = nbblocspassurbase+1
      print("1 bloc en dehors de la base de plus")
  if nbblocsajoutes <= maxblocs-1:
    clone_bloc(n_bloc_nom,n_bloc_x,n_bloc_y,"whitesmoke")
    nbblocsajoutes = nbblocsajoutes + 1
    print("in nouveau bloc: "+ str(n_bloc_nom))
  else:
    print("vous avez atteint le maximum nombre de blocs")
    messagebox.showwarning("Bloc #10","Vous avez atteint le maximum nombre de blocs")
    validation()
  print("blocs ajoutes: "+ str(nbblocsajoutes))

# a definir
def valider():
  if abs(round(bloc.xcor(), 5)) >= margeducentre:
    bloc.color("black", "salmon")
    print("hors de la marge du centre")
    if abs(round(bloc.xcor(), 5)) >= ((bloclargeur/2)+70):
        bloc.color("black", "red")
        print("bloc en dehors de la largeur de la base")
  else:
    bloc.color("black", "lime")
    print("dans la marge du centre")


# a definir
def validation():
  if nbblocsmalalignes >= 1:
    print("Blocs mal-alignes: " + str(nbblocsmalalignes))
    messagebox.showwarning("Attenion!","Votre construction n'est pas stable avec \n" + str(nbblocsmalalignes) + " bloc(s) mal centré(s)! \n" + str(nbblocspassurbase) + " bloc(s) en dehors de la largeur de la base!")
  else:
    print("Blocs mal-alignes: " + str(nbblocsmalalignes))
    messagebox.showinfo("Felicitations!","votre construction a l'air d'etre stable")
    

# afficher la messagebox d'intro avec les instructions
intro()

# dessiner le rectangle terre
dessin_rectangle_colorie(blocbase,-300,-200,terrelargeur,terrehauteur,1,"tan","tan")

# dessiner le rectangle base 
dessin_rectangle_colorie(blocbase,-100,-160,bloclargeur,blochauteur,1,blocbasecouleurligne,blocbasecouleur)
# dessine une 7x7 matrix de black squares
for x in range(1,11):
  for y in range(1,3):
    dessin_rectangle_colorie(blocbase,-120+x*20,-200+y*20,20,20,2,"white","grey")


fenetre.tracer(1) # Turns off the screen updates

# clavier bindings
fenetre.onkeypress(nouveau_bloc, "n")
fenetre.onkeypress(nouveau_bloc, "Return")
fenetre.onkeypress(validation, "v")
fenetre.onkeypress(gauche, "Left")
fenetre.onkeypress(gauche, "a")
fenetre.onkeypress(droite, "Right")
fenetre.onkeypress(droite, "d")
fenetre.onkeypress(exit, "x")
fenetre.listen()

fenetre.mainloop()

